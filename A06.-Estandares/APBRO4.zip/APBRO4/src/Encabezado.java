public class Encabezado {
    //-------------------------------------------------------------------------------------------
    static void encabezadoTabla() {
        System.out.println(
                "Usuario" +"                        | "+
                        "Cliente" +"                                  | "+
                        "Profesional" +"                  | "+
                        "Administrativo");

        System.out.println(
                "Nombre | " +
                        "fechaNacimiento | " +
                        "rUN | " +
                        "direccion | " +
                        "telefono | " +
                        "cantidadEmpleados | " +
                        "experienceYears | " +
                        "department | " +
                        "function| " +
                        "nombreSuperior"+
                        "\n" +
                        "-----------------------------------------------------" +
                        "--------------" +
                        "-------------------------------------------------------" +
                        "------------");

    }
}
