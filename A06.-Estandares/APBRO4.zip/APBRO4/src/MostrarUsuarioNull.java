import java.util.Arrays;

public class MostrarUsuarioNull {
    //-------------------------------------------------------------------------------------------
    static void mostrarUsuariosConNull(String[][] lista) {
        System.out.println("\n--------------TABLA-----------------" +
                "-------------------------------------------------" +
                "------------------------------------------------");
        Encabezado.encabezadoTabla();

        for (String[] strings : lista) {
            //ystem.out.println(" ");
            for (String string : strings) {
                System.out.print(string + " | ");
            }
            System.out.println("\n--------------------------------------" +
                    "-----------------------------------------------------");
        }

    }

    public static void main(String[] args) {
        mostrarUsuariosConNull(Main.lista);
    }
}
